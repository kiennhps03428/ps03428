<?php
$_['text_project']       = 'Project Homepage';
$_['text_documentation'] = 'Documentation';
$_['text_support']       = 'Support Forums';
$_['text_footer']        = 'Copyright © 2014 OpenCart - All rights reserved';